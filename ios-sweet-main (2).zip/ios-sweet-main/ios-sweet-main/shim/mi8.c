/*
 * Xiaomi Mi 8 (dipper, SDM845) bring-up diagnostic.
 *
 * The panel is a Samsung EA8074 AMOLED in DSI *command* mode: unlike the
 * video-mode panel on sweet it only changes when the display controller
 * (MDP/SDE) sends a frame, so drawing into ABL's splash buffer is not enough.
 * This build answers, in one boot and without touching storage:
 *   - what pipe/buffer/stride/format did ABL leave programmed (SSPP, CTL, PP, INTF)
 *   - does any of three manual frame triggers make the panel show new pixels
 * Everything is also written to the ramoops console zone (DDR survives a
 * warm reset), so it can be read back from Android even if the panel never
 * updates:  adb shell su -c "cat /sys/fs/pstore/console-ramoops*"
 *
 * Register offsets follow the Linux SDE driver (msm-4.9 sde_hw_*.c) and the
 * block bases come from the live FDT (qcom,sde-*-off). All accesses before
 * the "kick" steps are reads. No absolute pointers in data: ABL runs this
 * image wherever it likes with no relocation pass.
 */
#include <stdint.h>
#include "board.h"
#include "console.h"
#include "mi8.h"

#ifdef MI8_HOST
#include "mi8_host.h"
#else
#define rsr(r) ({ uint64_t _v; __asm__ volatile("mrs %0, " r : "=r"(_v)); _v; })
static inline uint32_t rd32(uintptr_t a) { return *(volatile uint32_t *)a; }
static inline void wr32(uintptr_t a, uint32_t v) { *(volatile uint32_t *)a = v; }
static inline void wr8(uintptr_t a, uint8_t v) { *(volatile uint8_t *)a = v; }
static inline void dsb(void) { __asm__ volatile("dsb sy" ::: "memory"); }
static inline uint64_t ticks(void) { __asm__ volatile("isb"); return rsr("cntpct_el0"); }
static inline uint64_t tfreq(void) { return rsr("cntfrq_el0"); }
#endif

/* ---- SDM845 display block map (live FDT) ---- */
#define MDP_BASE	0x0ae00000UL
#define CTL_OFF(n)	(0x2000 + (n) * 0x200)		/* qcom,sde-ctl-off */
#define PP_OFF(n)	(0x71000 + (n) * 0x800)		/* qcom,sde-pp-off */
#define INTF_1_OFF	0x6b800				/* DSI0 */
#define INTF_2_OFF	0x6c000				/* DSI1 */
#define DSI0_BASE	0x0ae94000UL

#define CTL_TOP		0x014
#define CTL_FLUSH	0x018
#define CTL_START	0x01c
#define CTL_INTF_ACTIVE	0x0f4
#define CTL_INTF_FLUSH	0x110
#define PP_TEAR_EN	0x000
#define PP_SYNC_VSYNC	0x004
#define PP_SYNC_HEIGHT	0x008
#define PP_LINE_COUNT	0x02c
#define PP_AUTOREFRESH	0x030

#define SSPP_SIZE	0x00
#define SSPP_SRC0_ADDR	0x14
#define SSPP_YSTRIDE0	0x2c
#define SSPP_FORMAT	0x30

/* ramoops@b0000000: 4 MB, record-size 0x40000, console-size 0x40000, ecc off.
 * The ROM kernel (4.9) puts the console zone after the dump records:
 * 4 * 0x40000 = +0x100000. +0x120000 is a hedge for kernels that lay it out
 * as size - console - ftrace - pmsg. */
#define PRZ_A		0xb0100000UL
#define PRZ_B		0xb0120000UL
#define PRZ_SIG		0x43474244U	/* 'DBGC' persistent_ram_buffer.sig */
#define LOG_MAX		7168

#define C_BLUE		0xff0000a0U
#define C_RED		0xffc00000U
#define C_GREEN		0xff006000U
#define C_PURPLE	0xff600080U

/* ---- result lines: filled at runtime, shown on screen and logged ---- */

struct line {
	const char *label, *an, *bn;
	uint32_t av, bv;
	int kind;	/* 0 = message, 1 = one or two hex values */
};

#define MAXL	80
static struct line L[MAXL];
static int nl;
static char labels[24][8];
static int nlab;
static char lb[LOG_MAX];
static unsigned ll;

static void msg(const char *label, const char *text)
{
	if (nl >= MAXL)
		return;
	L[nl].label = label;
	L[nl].an = text;
	L[nl].bn = 0;
	L[nl].av = L[nl].bv = 0;
	L[nl].kind = 0;
	nl++;
}

static void pair(const char *label, const char *an, uint32_t av, const char *bn, uint32_t bv)
{
	if (nl >= MAXL)
		return;
	L[nl].label = label;
	L[nl].an = an;
	L[nl].av = av;
	L[nl].bn = bn;
	L[nl].bv = bv;
	L[nl].kind = 1;
	nl++;
}

/* "SSPP" + digit, built into static storage (no pointer tables in data) */
static const char *mklabel(const char *prefix, int n)
{
	char *d;
	int i = 0;

	if (nlab >= 24)
		return prefix;
	d = labels[nlab++];
	while (*prefix && i < 6)
		d[i++] = *prefix++;
	d[i++] = '0' + n;
	d[i] = 0;
	return d;
}

static void lc(char c)
{
	if (ll < LOG_MAX - 1)
		lb[ll++] = c;
}

static void ls(const char *s)
{
	while (*s)
		lc(*s++);
}

static void lhex(uint32_t v)
{
	static const char hex[] = "0123456789abcdef";
	for (int i = 28; i >= 0; i -= 4)
		lc(hex[(v >> i) & 0xf]);
}

static void build_log(void)
{
	ll = 0;
	ls("MI8DIAG v1 ");
	ls(BOARD_NAME);
	lc('\n');
	for (int i = 0; i < nl; i++) {
		ls(L[i].label);
		lc(' ');
		ls(L[i].an);
		if (L[i].kind) {
			lhex(L[i].av);
			if (L[i].bn) {
				lc(' ');
				ls(L[i].bn);
				lhex(L[i].bv);
			}
		}
		lc('\n');
	}
}

/* struct persistent_ram_buffer { u32 sig; u32 start; u32 size; u8 data[]; } */
static void prz_write(uintptr_t zone)
{
	for (unsigned i = 0; i < ll; i++)
		wr8(zone + 12 + i, (uint8_t)lb[i]);
	wr32(zone + 4, 0);
	wr32(zone + 8, ll);
	wr32(zone + 0, PRZ_SIG);
}

static void flush_log(void)
{
	build_log();
	prz_write(PRZ_A);
	prz_write(PRZ_B);
	dsb();
}

/* ---- display ---- */

static void delay_ms(unsigned ms)
{
	uint64_t end = ticks() + tfreq() / 1000 * ms;

	while (ticks() < end)
		;
}

static void render(uint32_t bg, const char *title)
{
	con_clear(bg);
	con_str("MI8", title);
	for (int i = 0; i < nl; i++) {
		if (L[i].kind == 0)
			con_str(L[i].label, L[i].an);
		else
			con_hex2(L[i].label, L[i].an, L[i].av, L[i].bn, L[i].bv);
	}
	dsb();
}

static void post(int n)
{
	pair(mklabel("POST", n), "pp0c=", rd32(MDP_BASE + PP_OFF(0) + PP_LINE_COUNT),
	     "ctl0s=", rd32(MDP_BASE + CTL_OFF(0) + CTL_START));
}

static void scan_pipes(uint32_t *fb_addr, uint32_t *fb_stride)
{
	static const uint32_t sspp_off[8] = {
		0x5000, 0x7000, 0x9000, 0xb000, 0x25000, 0x27000, 0x29000, 0x2b000,
	};
	int active = 0;

	*fb_addr = 0;
	*fb_stride = 0;
	for (int i = 0; i < 8; i++) {
		uintptr_t b = MDP_BASE + sspp_off[i];
		uint32_t addr = rd32(b + SSPP_SRC0_ADDR);

		if (!addr)
			continue;
		active++;
		uint32_t ys = rd32(b + SSPP_YSTRIDE0);
		const char *l = mklabel("SSPP", i);

		pair(l, "addr=", addr, "ystr=", ys);
		pair(" fmt", "fmt=", rd32(b + SSPP_FORMAT), "size=", rd32(b + SSPP_SIZE));
		if (!*fb_addr && addr >= 0x80000000U) {
			*fb_addr = addr;
			*fb_stride = ys & 0xffff;
		}
	}
	pair("SSPPs", "active=", active, 0, 0);
}

void mi8_diag(uintptr_t dtb)
{
	uint32_t fb_addr, fb_stride;

	nl = 0;
	msg("BOARD", BOARD_NAME);
	pair("CPU", "midr=", (uint32_t)rsr("midr_el1"), "mpidr=", (uint32_t)rsr("mpidr_el1"));
	pair("MMFR0", "tg16=", (rsr("id_aa64mmfr0_el1") >> 20) & 0xf, "parng=", rsr("id_aa64mmfr0_el1") & 0xf);
	pair("EL", "cur=", (uint32_t)(rsr("currentel") >> 2), "sctlr=", (uint32_t)rsr("sctlr_el1"));
	pair("DTB", "at=", (uint32_t)dtb, "magic=", dtb ? __builtin_bswap32(rd32(dtb)) : 0);
	flush_log();	/* first thing: proves ramoops works even if MDSS reads hang */

	pair("MDP", "rev=", rd32(MDP_BASE), 0, 0);
	flush_log();

	scan_pipes(&fb_addr, &fb_stride);
	if (fb_addr) {
		con_fb = (volatile uint32_t *)(uintptr_t)fb_addr;
		if (fb_stride && !(fb_stride & 3) && fb_stride <= 16384)
			con_stride4 = fb_stride / 4;
		if (fb_addr != FB_BASE)
			msg("FB", "ABL buffer is not cont_splash base");
	} else {
		msg("FB", "no active SSPP: splash off?");
	}
	pair("FBUSE", "base=", (uint32_t)(uintptr_t)con_fb, "str4=", con_stride4);
	flush_log();

	for (int i = 0; i < 2; i++) {
		uintptr_t c = MDP_BASE + CTL_OFF(i);

		pair(mklabel("CTL", i), "top=", rd32(c + CTL_TOP), "flush=", rd32(c + CTL_FLUSH));
		pair(" ", "start=", rd32(c + CTL_START), "intfa=", rd32(c + CTL_INTF_ACTIVE));
	}
	flush_log();

	for (int i = 0; i < 2; i++) {
		uintptr_t p = MDP_BASE + PP_OFF(i);

		pair(mklabel("PP", i), "tear=", rd32(p + PP_TEAR_EN), "vsync=", rd32(p + PP_SYNC_VSYNC));
		pair(" ", "hght=", rd32(p + PP_SYNC_HEIGHT), "auto=", rd32(p + PP_AUTOREFRESH));
	}
	flush_log();

	pair("INTF1", "en=", rd32(MDP_BASE + INTF_1_OFF), "cfg=", rd32(MDP_BASE + INTF_1_OFF + 4));
	pair("INTF2", "en=", rd32(MDP_BASE + INTF_2_OFF), "cfg=", rd32(MDP_BASE + INTF_2_OFF + 4));
	pair("DSI0", "ctrl=", rd32(DSI0_BASE + 4), 0, 0);
	flush_log();

	/* Step 0: no trigger. If this shows, the panel is not really command-mode-only. */
	render(C_BLUE, "step0 blue: no trigger");
	flush_log();
	delay_ms(4000);

	/* Step 1: CTL0 START */
	render(C_RED, "step1 RED: CTL0 START");
	wr32(MDP_BASE + CTL_OFF(0) + CTL_START, 1);
	dsb();
	delay_ms(6000);
	post(1);

	/* Step 2: CTL1 START */
	render(C_GREEN, "step2 GREEN: CTL1 START");
	wr32(MDP_BASE + CTL_OFF(1) + CTL_START, 1);
	dsb();
	delay_ms(6000);
	post(2);

	/* Step 3: PP0 auto-refresh (enable, 1 frame) + CTL0 START */
	render(C_PURPLE, "step3 PURPLE: PP0 AUTOREFRESH");
	wr32(MDP_BASE + PP_OFF(0) + PP_AUTOREFRESH, (1U << 31) | 1);
	wr32(MDP_BASE + CTL_OFF(0) + CTL_START, 1);
	dsb();
	delay_ms(6000);
	post(3);

	pair("PP0", "auto=", rd32(MDP_BASE + PP_OFF(0) + PP_AUTOREFRESH), 0, 0);
	flush_log();
	render(C_BLUE, "done: rebooting");
	delay_ms(10000);
}

void mi8_panic_log(const char *stage, uint64_t slot, uint64_t esr, uint64_t elr, uint64_t far)
{
	msg("PANIC", stage);
	pair("SLOT", "n=", (uint32_t)slot, "esr=", (uint32_t)esr);
	pair(" ", "elr=", (uint32_t)elr, "far=", (uint32_t)far);
	flush_log();
}
