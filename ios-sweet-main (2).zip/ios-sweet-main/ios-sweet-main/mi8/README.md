# Mi 8 (dipper, SDM845) bring-up

First target for the ios-sweet approach on a Snapdragon 845 phone. Status: **diagnostic shim only**,
nothing boots XNU yet. It answers the one question that decides whether this port is cheap or not:
the panel (Samsung EA8074 AMOLED) is DSI **command mode**, so unlike sweet's video-mode panel, copying
pixels into ABL's splash buffer will not change what you see unless the display controller is told to
send a frame.

## What the diagnostic does (no storage access, no writes except display triggers and a RAM log)

1. Reads the display pipeline ABL left programmed: SSPP (source buffer address, stride, format, size),
   CTL0/1, PP0/1, INTF1/2, DSI0. Picks the buffer ABL is actually scanning out and draws into it.
2. Shows 4 colour screens, 4-6 s apart, each with the register dump on it:
   - step 0 **blue**: no trigger (if you see it, the panel refreshes by itself)
   - step 1 **red**: after `CTL0_START = 1`
   - step 2 **green**: after `CTL1_START = 1`
   - step 3 **purple**: after enabling `PP0 auto-refresh` and `CTL0_START`
   - then a final blue "done" screen and a reset (~10 s later).
3. Writes the same data to the ramoops console zone, so it is readable from Android even if the panel
   never changes.

## Build

CI (no local toolchain): push to your GitHub fork, Actions -> **mi8-shim** -> Run workflow, download the
`mi8-diag` artifact. Local (Linux/WSL): `sudo apt install gcc-aarch64-linux-gnu binutils-aarch64-linux-gnu`
then `bash mi8/build-mi8.sh` -> `mi8/out/mi8-diag-gz.img`, `mi8/out/mi8-diag-ucomp.img`.

The build also runs a host test of `shim/mi8.c` against a fake MMIO + ramoops (`mi8/host/`).

## Run (TWRP not needed; nothing is flashed)

```
fastboot boot mi8-diag-gz.img
```

- Phone not booting the image (stays in fastboot / "boot image invalid"): try `mi8-diag-ucomp.img`.
- Either one: if neither is accepted, note the exact fastboot message and send it.
- Watch the screen. Note which colours appear and in which order (blue, red, green, purple, or none).
- If the phone hangs for more than ~90 s, hold power until it restarts (a forced power-off may lose the log).

## Read the log back

The shim resets to Android when it finishes. In Android, with root:

```
adb shell su -c "ls /sys/fs/pstore; cat /sys/fs/pstore/console-ramoops*" > mi8-log.txt
```

(or in TWRP if its kernel has pstore). The log starts with `MI8DIAG v1 mi8 dipper sdm845`. Send it back.
If `/sys/fs/pstore` is empty, the reset lost DDR or the console zone is elsewhere; build with
`MI8_RESET=bootloader` (Actions input `reset: bootloader`) and rely on the screen instead.

## Constants (from the live FDT of this phone)

| thing | value |
|---|---|
| ABL splash buffer | `0x9d400000`, 36 MB (cont_splash_region), panel 1080x2248 |
| MDP base | `0xae00000`; CTL `+0x2000/+0x200n`; PP `+0x71000/+0x800n`; INTF1 (DSI0) `+0x6b800`; DSI0 `0xae94000` |
| UFS | `0x1d84000` (SK hynix, ABL leaves HS-G3 2-lane unset; Linux negotiates later) |
| GICv3 | GICD `0x17a00000`, GICR `0x17a60000` stride `0x20000`, PSCI via smc |
| IMEM restart reason | `0x146bf65c` |
| RAM | 3 GB at `0x80000000` + about 3.95 GiB at `0x100000000..0x1fd400000`, no carve-outs above 4 GiB |
| ramoops | `0xb0000000`, 4 MB; console zone expected at `+0x100000` (also written at `+0x120000`) |
| CPUs | cpu0-3 Kryo 385 Silver (A55-based, part 0x803), cpu4-7 Gold (0x802) |
| boot image | header v1, 4 KB pages, DTB appended to the kernel, ABL selects by msm-id 321/0x20001 board-id 55 |

## Safety

`fastboot boot` only. The diagnostic never touches UFS or any partition. Back up the small partitions and
the GPT heads/tails (see the top-level README) before any later step that writes to `userdata`.
