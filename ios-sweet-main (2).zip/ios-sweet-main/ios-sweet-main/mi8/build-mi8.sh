#!/bin/bash
# Build the Mi 8 (dipper, SDM845) diagnostic shim and pack it into fastboot-bootable boot images.
#   needs: aarch64-linux-gnu-{gcc,objcopy,nm,readelf} (apt: gcc-aarch64-linux-gnu), python3
#   MI8_RESET=android (default) | bootloader : where the shim resets to when it is done
# Output: mi8/out/mi8-diag-gz.img (try first) and mi8/out/mi8-diag-ucomp.img (fallback).
# Never flash these: `fastboot boot <img>` only.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
shim="$here/../shim"
out="$here/out"
CROSS="${CROSS:-aarch64-linux-gnu-}"
CC="${CROSS}gcc"; OBJCOPY="${CROSS}objcopy"; NM="${CROSS}nm"; READELF="${CROSS}readelf"
CFLAGS="-O2 -ffreestanding -nostdlib -fno-pic -mgeneral-regs-only -mstrict-align -fno-stack-protector -Wall -Wextra -DTARGET_MI8 -I$shim"
if [ "${MI8_RESET:-android}" = bootloader ]; then CFLAGS="$CFLAGS -DMI8_RESET_BOOTLOADER"; fi
rm -rf "$out"; mkdir -p "$out"
# Host tests first: shim/mi8.c against a fake MMIO + ramoops, and the console layout.
gcc -O1 -Wall -Wextra -DMI8_HOST -DTARGET_MI8 -I"$shim" -I"$here/host" -o "$out/test_mi8" "$here/host/test_mi8.c" "$shim/mi8.c"
"$out/test_mi8"
for f in start.S shim.c console.c mmu.c fdt.c loader.c ufs.c mi8.c; do
	$CC $CFLAGS -c "$shim/$f" -o "$out/${f%.*}.o"
done
# The image runs wherever ABL puts it with no relocation pass.
abs=$($READELF -r "$out"/{shim,console,mmu,fdt,loader,ufs,mi8}.o | grep -c ABS64 || true)
[ "$abs" = 0 ] || { echo "error: $abs absolute relocations in C objects" >&2; exit 1; }
$CC $CFLAGS -static -T "$shim/shim.ld" -Wl,--build-id=none -Wl,--no-warn-rwx-segments -Wl,-N \
	"$out"/{start,shim,console,mmu,fdt,loader,ufs,mi8}.o -o "$out/shim.elf"
$OBJCOPY -O binary "$out/shim.elf" "$out/Image"
size=$((16#$($NM "$out/shim.elf" | awk '$3=="_end"{print $1}')))
truncate -s "$size" "$out/Image"
for mode in gz ucomp; do
	python3 "$here/mkimg_v1.py" --image "$out/Image" --dtb "$here/fdt/mi8-dipper-mp-v2.1.dtb" \
		--mode "$mode" --out "$out/mi8-diag-$mode.img"
done
ls -l "$out"/Image "$out"/mi8-diag-*.img
